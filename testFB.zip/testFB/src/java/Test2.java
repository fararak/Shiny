
import java.util.List;
import org.springframework.social.facebook.api.Facebook;
import org.springframework.social.facebook.api.Post;
import org.springframework.social.facebook.api.impl.FacebookTemplate;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Hp Gamers
 */
public class Test2 {
    public Facebook getApi(String token){
        FacebookTemplate template = new FacebookTemplate(token);
        return template;
    }
    public void tester(String token){
        Facebook fb = getApi(token);
        List<Post> lp = fb.feedOperations().getPosts();
        for(int i=0;i<lp.size();i++){
            System.out.println("io: "+lp.get(i).getLikeCount());
       }
        
    }
}
