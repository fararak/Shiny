
import fb_Dao.PostDao;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Hp Gamers
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        // TODO code application logic here
       // Test2 t = new Test2();
      
      String token = "EAAfMCNDvBNgBADiM54rhl0BUNBZCzOo2S3csBsAU3ouyJLZCP0Iuz1J9pLn7WnZAuJZAnLIAQq2hdQ362A4oSOZCnbDv7OZBdBPHZB0k9g1xkwL8YHQf2omiw6cZBmpuKii7jJeZBXxieESRPrMIMcs4iRJACHPKLI30X7l1zVZCvKEnDSYZBGhHp3A5JUBsdbQypQ9slANc291owZDZD";
       // t.tester(token);
      PostDao pdao = new PostDao();
       pdao.getMe(token);
    }
    
}
